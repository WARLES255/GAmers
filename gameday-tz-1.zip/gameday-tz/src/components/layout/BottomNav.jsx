import { useNavigate, useLocation } from 'react-router-dom'
import { Trophy, Swords, BarChart2, User, Plus } from 'lucide-react'

const navItems = [
  { path: '/', icon: Trophy, label: 'Tournaments' },
  { path: '/mechi', icon: Swords, label: 'Mechi' },
  { path: '/bodi', icon: BarChart2, label: 'Bodi' },
  { path: '/profaili', icon: User, label: 'Profaili' },
]

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <nav className="bottom-nav fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white border-t border-gray-100 z-50">
      <div className="flex items-center justify-around px-2 pt-2 pb-2 relative">
        {navItems.map((item, index) => {
          const isActive = location.pathname === item.path
          const Icon = item.icon

          // Insert FAB in the middle
          if (index === 2) {
            return (
              <>
                {/* FAB */}
                <button
                  key="fab"
                  onClick={() => navigate('/tournament/create')}
                  className="absolute -top-6 left-1/2 -translate-x-1/2 w-14 h-14 rounded-full bg-[#00C853] flex items-center justify-center shadow-lg shadow-green-200 active:scale-90 transition-transform"
                >
                  <Plus size={28} className="text-white" strokeWidth={2.5} />
                </button>

                {/* Spacer */}
                <div key="spacer" className="w-14" />

                {/* The actual item */}
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className="flex flex-col items-center gap-0.5 px-3 py-1 active:scale-90 transition-transform"
                >
                  <Icon size={22} className={isActive ? 'text-[#00C853]' : 'text-gray-400'} />
                  <span className={`text-[10px] font-semibold ${isActive ? 'text-[#00C853]' : 'text-gray-400'}`}>
                    {item.label}
                  </span>
                </button>
              </>
            )
          }

          return (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="flex flex-col items-center gap-0.5 px-3 py-1 active:scale-90 transition-transform"
            >
              <Icon size={22} className={isActive ? 'text-[#00C853]' : 'text-gray-400'} />
              <span className={`text-[10px] font-semibold ${isActive ? 'text-[#00C853]' : 'text-gray-400'}`}>
                {item.label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
