import { Bell, Share2, Wallet } from 'lucide-react'
import { useAuth } from '../../context/AuthContext'

export default function TopBar() {
  const { profile } = useAuth()

  const balance = profile?.wallet_balance ?? 0
  const formatted = new Intl.NumberFormat('sw-TZ').format(balance)

  return (
    <div className="sticky top-0 z-50 bg-white border-b border-gray-100 px-4 py-3">
      <div className="flex items-center justify-between">
        {/* Greeting */}
        <div className="flex items-center gap-2">
          <span className="text-lg">👋</span>
          <div>
            <p className="text-xs text-gray-500">Habari,</p>
            <p className="font-bold text-sm text-gray-900">{profile?.username ?? 'Mchezaji'}</p>
          </div>
        </div>

        {/* Right: wallet + icons */}
        <div className="flex items-center gap-3">
          {/* Wallet balance */}
          <div className="flex items-center gap-1.5 bg-gray-50 rounded-xl px-3 py-1.5">
            <Wallet size={14} className="text-[#FF6B00]" />
            <div className="text-right">
              <p className="text-[10px] text-gray-400 leading-none">TZS</p>
              <p className="text-sm font-bold text-[#FF6B00] leading-tight">{formatted}</p>
            </div>
          </div>

          {/* Share */}
          <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-50 text-gray-600 active:scale-90 transition-transform">
            <Share2 size={16} />
          </button>

          {/* Bell */}
          <button className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-50 text-gray-600 active:scale-90 transition-transform relative">
            <Bell size={16} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#00C853]" />
          </button>
        </div>
      </div>
    </div>
  )
}
