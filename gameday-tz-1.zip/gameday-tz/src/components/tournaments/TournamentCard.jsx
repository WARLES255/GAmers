import { useNavigate } from 'react-router-dom'
import { Trophy } from 'lucide-react'

const GAME_ICONS = {
  'eFootball': '⚽',
  'Free Fire': '🔥',
  'Asphalt 9': '🏎️',
  'Mortal Kombat': '👊',
  'PUBG': '🎯',
  'FIFA': '⚽',
  'Chess': '♟️',
  default: '🎮'
}

const STATUS_BADGE = {
  open: <span className="badge-open">WAZI</span>,
  live: <span className="badge-live">LIVE</span>,
  completed: <span className="badge-ended">IMEKWISHA</span>,
  cancelled: <span className="badge-ended">IMEFUTWA</span>,
}

function formatTZS(amount) {
  if (amount >= 1000000) return `TZS ${(amount/1000000).toFixed(1)}M`
  if (amount >= 1000) return `TZS ${new Intl.NumberFormat('sw-TZ').format(amount)}`
  return `TZS ${amount}`
}

export default function TournamentCard({ tournament, featured = false }) {
  const navigate = useNavigate()
  const icon = GAME_ICONS[tournament.game] ?? GAME_ICONS.default
  const filled = tournament.current_participants / tournament.max_participants
  const spotsLeft = tournament.max_participants - tournament.current_participants

  if (featured) {
    return (
      <div
        className="bg-gradient-to-br from-[#1a3a2a] to-[#2d5a3d] rounded-2xl p-5 mb-4 animate-fadeIn cursor-pointer active:scale-[0.98] transition-transform"
        onClick={() => navigate(`/tournament/${tournament.id}`)}
      >
        <div className="flex items-center gap-2 mb-3">
          <span className="text-2xl">{icon}</span>
          <div>
            <p className="text-white/60 text-xs">{tournament.game}</p>
            {STATUS_BADGE[tournament.status]}
          </div>
        </div>

        <h2 className="text-white font-bold text-2xl mb-3">{tournament.title}</h2>

        <div className="flex items-center gap-2 mb-4">
          <Trophy size={18} className="text-[#FF6B00]" />
          <span className="text-[#FF6B00] font-bold text-2xl">{formatTZS(tournament.prize_pool)}</span>
        </div>

        {/* Progress bar */}
        <div className="mb-2">
          <div className="flex justify-between text-xs text-white/60 mb-1">
            <span>{tournament.current_participants}/{tournament.max_participants} wamejoin</span>
            <span>Ingiza: {formatTZS(tournament.entry_fee)}</span>
          </div>
          <div className="h-2 bg-white/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#00C853] rounded-full transition-all duration-500"
              style={{ width: `${filled * 100}%` }}
            />
          </div>
        </div>

        <p className="text-white/40 text-xs mb-4">Hivi Karibuni</p>

        <button
          className="w-full bg-[#00C853] text-white font-bold py-3.5 rounded-xl text-sm tracking-wide active:scale-95 transition-transform"
          onClick={(e) => { e.stopPropagation(); navigate(`/tournament/${tournament.id}`) }}
        >
          JIUNGE SASA
        </button>
      </div>
    )
  }

  return (
    <div
      className="card mb-3 cursor-pointer active:scale-[0.98] transition-transform animate-fadeIn"
      onClick={() => navigate(`/tournament/${tournament.id}`)}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-xl">
            {icon}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <h3 className="font-bold text-sm text-gray-900 truncate">{tournament.title}</h3>
            </div>
            <p className="text-xs text-gray-400">{tournament.game}</p>
          </div>
        </div>
        {STATUS_BADGE[tournament.status]}
      </div>

      <div className="flex items-center justify-between mt-3">
        <div className="flex items-center gap-1.5">
          <Trophy size={14} className="text-[#FF6B00]" />
          <span className="prize-amount text-base">{formatTZS(tournament.prize_pool)}</span>
          <span className="text-xs text-gray-400 ml-1">
            {tournament.current_participants}/{tournament.max_participants}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400">Ingiza: {formatTZS(tournament.entry_fee)}</span>
          {tournament.status === 'open' && spotsLeft > 0 && (
            <button
              className="bg-[#00C853] text-white text-xs font-bold px-3 py-1.5 rounded-lg active:scale-90 transition-transform"
              onClick={(e) => { e.stopPropagation(); navigate(`/tournament/${tournament.id}`) }}
            >
              JIUNGE
            </button>
          )}
          {tournament.status === 'live' && (
            <button className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 text-xs font-bold">
              ↗
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
