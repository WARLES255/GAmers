import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { ArrowLeft, Trophy, Users, Clock, Shield } from 'lucide-react'

function formatTZS(n) {
  return new Intl.NumberFormat('sw-TZ').format(n ?? 0)
}

export default function TournamentDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { profile, refreshProfile } = useAuth()
  const [tournament, setTournament] = useState(null)
  const [participants, setParticipants] = useState([])
  const [hasJoined, setHasJoined] = useState(false)
  const [loading, setLoading] = useState(true)
  const [joining, setJoining] = useState(false)
  const [activeTab, setActiveTab] = useState('info')

  useEffect(() => {
    fetchTournament()
    fetchParticipants()
  }, [id])

  useEffect(() => {
    if (profile && participants.length) {
      setHasJoined(participants.some(p => p.user_id === profile.id))
    }
  }, [participants, profile])

  async function fetchTournament() {
    const { data } = await supabase
      .from('tournaments')
      .select('*, creator:profiles!tournaments_created_by_fkey(username)')
      .eq('id', id)
      .single()
    setTournament(data)
    setLoading(false)
  }

  async function fetchParticipants() {
    const { data } = await supabase
      .from('tournament_participants')
      .select('*, profile:profiles(username, total_wins, total_games)')
      .eq('tournament_id', id)
      .order('joined_at', { ascending: true })
    setParticipants(data ?? [])
  }

  async function handleJoin() {
    if (!profile || hasJoined || joining) return
    if (profile.wallet_balance < tournament.entry_fee) {
      alert('Pesa haitoshi kwenye mkoba wako. Tafadhali ongeza pesa.')
      return
    }

    setJoining(true)

    // Deduct entry fee and add participant
    const { error } = await supabase.rpc('join_tournament', {
      p_tournament_id: id,
      p_user_id: profile.id,
      p_entry_fee: tournament.entry_fee
    })

    if (error) {
      alert('Hitilafu imetokea. Jaribu tena.')
    } else {
      await Promise.all([fetchTournament(), fetchParticipants(), refreshProfile()])
      setHasJoined(true)
    }

    setJoining(false)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-10 h-10 border-4 border-[#00C853] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!tournament) return null

  const statusColor = {
    open: 'text-[#00C853]',
    live: 'text-[#00C853]',
    completed: 'text-gray-400',
  }[tournament.status] ?? 'text-gray-400'

  const spotsLeft = tournament.max_participants - tournament.current_participants
  const fillPercent = (tournament.current_participants / tournament.max_participants) * 100

  return (
    <div className="pb-32">
      {/* Hero */}
      <div className="bg-gradient-to-br from-[#1a3a2a] to-[#2d5a3d] px-4 pt-4 pb-8 relative">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center mb-4 active:scale-90 transition-transform"
        >
          <ArrowLeft size={18} className="text-white" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <span className="text-3xl">⚽</span>
          <div>
            <p className="text-white/60 text-xs">{tournament.game}</p>
            <span className={`text-xs font-bold ${statusColor} bg-white/10 px-2 py-0.5 rounded`}>
              {tournament.status.toUpperCase()}
            </span>
          </div>
        </div>

        <h1 className="text-white text-2xl font-extrabold mb-4">{tournament.title}</h1>

        <div className="flex items-center gap-2 mb-4">
          <Trophy size={20} className="text-[#FF6B00]" />
          <span className="text-[#FF6B00] font-extrabold text-2xl">TZS {formatTZS(tournament.prize_pool)}</span>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <Users size={16} className="text-white/60 mx-auto mb-1" />
            <p className="text-white font-bold text-sm">{tournament.current_participants}/{tournament.max_participants}</p>
            <p className="text-white/40 text-[10px]">Washiriki</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <Shield size={16} className="text-white/60 mx-auto mb-1" />
            <p className="text-white font-bold text-sm">TZS {formatTZS(tournament.entry_fee)}</p>
            <p className="text-white/40 text-[10px]">Ingiza</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 text-center">
            <Clock size={16} className="text-white/60 mx-auto mb-1" />
            <p className="text-white font-bold text-sm">{spotsLeft}</p>
            <p className="text-white/40 text-[10px]">Nafasi</p>
          </div>
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-3 bg-white border-b border-gray-100">
        <div className="flex justify-between text-xs text-gray-500 mb-1">
          <span>{tournament.current_participants} wamejoin</span>
          <span>{spotsLeft} nafasi zimebaki</span>
        </div>
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#00C853] rounded-full transition-all duration-700"
            style={{ width: `${fillPercent}%` }}
          />
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 bg-white px-4">
        {[['info', 'Maelezo'], ['participants', 'Washiriki'], ['bracket', 'Bracket']].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`px-4 py-3 text-sm font-semibold border-b-2 transition-all ${
              activeTab === key ? 'border-[#00C853] text-[#00C853]' : 'border-transparent text-gray-400'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="px-4 pt-4">
        {/* Info tab */}
        {activeTab === 'info' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="card">
              <h3 className="font-bold mb-2">Maelezo ya Tournament</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex justify-between">
                  <span className="text-gray-400">Mchezo</span>
                  <span className="font-semibold">{tournament.game}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Aina ya Bracket</span>
                  <span className="font-semibold capitalize">{tournament.bracket_type?.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Imeundwa na</span>
                  <span className="font-semibold">{tournament.creator?.username ?? 'GameDay TZ'}</span>
                </div>
                {tournament.starts_at && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">Inaanza</span>
                    <span className="font-semibold">{new Date(tournament.starts_at).toLocaleString('sw-TZ')}</span>
                  </div>
                )}
              </div>
            </div>

            {tournament.rules && (
              <div className="card">
                <h3 className="font-bold mb-2">Sheria za Mchezo</h3>
                <p className="text-sm text-gray-600 whitespace-pre-line">{tournament.rules}</p>
              </div>
            )}

            {/* Prize breakdown */}
            <div className="card">
              <h3 className="font-bold mb-3">Mgawanyo wa Tuzo</h3>
              {[
                { place: '🥇 1st', pct: 60 },
                { place: '🥈 2nd', pct: 30 },
                { place: '🥉 3rd', pct: 10 },
              ].map(({ place, pct }) => (
                <div key={place} className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0">
                  <span className="font-semibold text-sm">{place}</span>
                  <span className="text-[#FF6B00] font-bold text-sm">
                    TZS {formatTZS(Math.round(tournament.prize_pool * pct / 100))}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Participants tab */}
        {activeTab === 'participants' && (
          <div className="space-y-2 animate-fadeIn">
            {participants.length === 0 ? (
              <div className="text-center py-12">
                <Users size={40} className="text-gray-200 mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Bado hakuna washiriki</p>
              </div>
            ) : (
              participants.map((p, i) => (
                <div key={p.id} className="card flex items-center gap-3">
                  <span className="text-gray-400 font-bold text-sm w-5">{i + 1}</span>
                  <div className="w-9 h-9 rounded-full bg-[#00C853]/10 flex items-center justify-center font-bold text-[#00C853]">
                    {p.profile?.username?.[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm">{p.profile?.username}</p>
                    <p className="text-xs text-gray-400">
                      {p.profile?.total_wins}W · {p.profile?.total_games} mechi
                    </p>
                  </div>
                  <span className="text-xs text-gray-300">
                    {new Date(p.joined_at).toLocaleDateString('sw-TZ')}
                  </span>
                </div>
              ))
            )}
          </div>
        )}

        {/* Bracket tab */}
        {activeTab === 'bracket' && (
          <div className="animate-fadeIn text-center py-12">
            <span className="text-5xl block mb-4">🏆</span>
            <p className="font-semibold text-gray-500">Bracket itaonekana tournament ikianza</p>
            <p className="text-xs text-gray-400 mt-1">
              {spotsLeft > 0 ? `Inangoja washiriki ${spotsLeft} zaidi` : 'Tournament iko karibu kuanza!'}
            </p>
          </div>
        )}
      </div>

      {/* Bottom CTA */}
      {tournament.status === 'open' && (
        <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] bg-white border-t border-gray-100 px-4 pt-3 pb-8">
          {hasJoined ? (
            <div className="flex items-center justify-center gap-2 bg-green-50 py-4 rounded-xl">
              <span className="text-[#00C853] font-bold">✓ Umejiunga tayari!</span>
            </div>
          ) : (
            <button
              onClick={handleJoin}
              disabled={joining || spotsLeft === 0}
              className="w-full bg-[#00C853] text-white font-bold py-4 rounded-xl text-base tracking-wide disabled:opacity-50 active:scale-95 transition-transform"
            >
              {joining ? 'Inajiunga...' :
               spotsLeft === 0 ? 'IMEJAA' :
               `JIUNGE — TZS ${formatTZS(tournament.entry_fee)}`}
            </button>
          )}
        </div>
      )}
    </div>
  )
}
