import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { ArrowLeft } from 'lucide-react'

export default function Register() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ username: '', fullName: '', phone: '', password: '', confirm: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  function update(k, v) { setForm(p => ({ ...p, [k]: v })) }

  async function handleRegister() {
    if (!form.username || !form.phone || !form.password) {
      setError('Jaza sehemu zote')
      return
    }
    if (form.password !== form.confirm) {
      setError('Maneno ya siri hayafanani')
      return
    }
    if (form.password.length < 6) {
      setError('Neno la siri liwe na herufi 6 angalau')
      return
    }

    setLoading(true)
    setError('')

    const { error } = await signUp({
      phone: `+255${form.phone.replace(/^0/, '')}`,
      password: form.password,
      username: form.username,
      fullName: form.fullName,
    })

    if (error) setError(error.message)
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-white px-6 pt-10 pb-10">
      <button
        onClick={() => navigate('/login')}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center mb-6 active:scale-90 transition-transform"
      >
        <ArrowLeft size={18} />
      </button>

      <h1 className="text-2xl font-extrabold mb-1">Jisajili 👋</h1>
      <p className="text-gray-400 text-sm mb-8">Unda akaunti yako ya GameDay TZ</p>

      <div className="space-y-4 mb-6">
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Jina la Mchezo (Username) *</label>
          <input
            type="text"
            placeholder="Mfano: DarKing99"
            value={form.username}
            onChange={e => update('username', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Jina Kamili (hiari)</label>
          <input
            type="text"
            placeholder="Jina lako kamili"
            value={form.fullName}
            onChange={e => update('fullName', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Namba ya Simu *</label>
          <div className="flex items-center border-2 border-gray-100 rounded-xl overflow-hidden focus-within:border-[#00C853]">
            <span className="px-3 py-3.5 bg-gray-50 text-sm font-semibold text-gray-500 border-r border-gray-100">+255</span>
            <input
              type="tel"
              placeholder="712 345 678"
              value={form.phone}
              onChange={e => update('phone', e.target.value)}
              className="flex-1 px-3 py-3.5 text-sm font-medium focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Neno la Siri *</label>
          <input
            type="password"
            placeholder="Angalau herufi 6"
            value={form.password}
            onChange={e => update('password', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Thibitisha Neno la Siri *</label>
          <input
            type="password"
            placeholder="Rudia neno la siri"
            value={form.confirm}
            onChange={e => update('confirm', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center bg-red-50 py-2 rounded-xl">{error}</p>
        )}

        <button
          onClick={handleRegister}
          disabled={loading}
          className="w-full bg-[#00C853] text-white font-extrabold py-4 rounded-xl text-base disabled:opacity-50 active:scale-95 transition-transform"
        >
          {loading ? 'Inasajili...' : 'JISAJILI'}
        </button>
      </div>

      <p className="text-center text-sm text-gray-400">
        Una akaunti tayari?{' '}
        <button onClick={() => navigate('/login')} className="text-[#00C853] font-bold">
          Ingia hapa
        </button>
      </p>
    </div>
  )
}
