import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

const SKULLS = ['💀', '⚡', '👑', '🦁', '🔥', '🎮', '🐍', '♟️']

function formatTZS(n) {
  if (n >= 1000000) return `TZS ${(n/1000000).toFixed(1)}M`
  return `TZS ${new Intl.NumberFormat('sw-TZ').format(n)}`
}

export default function Bodi() {
  const { profile } = useAuth()
  const [activeTab, setActiveTab] = useState('week')
  const [players, setPlayers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLeaderboard()
  }, [activeTab])

  async function fetchLeaderboard() {
    setLoading(true)
    const now = new Date()
    const week = getWeekNumber(now)
    const month = now.getMonth() + 1
    const year = now.getFullYear()

    let query = supabase
      .from('leaderboard_points')
      .select('*, profile:profiles(username, avatar_url, total_wins, total_games, total_earnings)')
      .order('points', { ascending: false })
      .limit(50)

    if (activeTab === 'week') {
      query = query.eq('week_number', week).eq('year', year)
    } else if (activeTab === 'month') {
      query = query.eq('month_number', month).eq('year', year)
    }

    const { data } = await query
    setPlayers(data ?? [])
    setLoading(false)
  }

  function getWeekNumber(d) {
    const onejan = new Date(d.getFullYear(), 0, 1)
    return Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7)
  }

  const top3 = players.slice(0, 3)
  const rest = players.slice(3)

  return (
    <div className="px-4 pt-6">
      <h1 className="text-2xl font-extrabold mb-4 flex items-center gap-2">
        Viongozi wa GameDay <span>📊</span>
      </h1>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {[['week', 'Wiki Hii'], ['month', 'Mwezi Huu'], ['all', 'Wote']].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`px-4 py-2 rounded-full font-semibold text-sm transition-all ${
              activeTab === key ? 'bg-[#00C853] text-white' : 'bg-white text-gray-500 border border-gray-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1,2,3,4,5].map(i => (
            <div key={i} className="h-16 bg-gray-100 rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : players.length === 0 ? (
        <div className="flex flex-col items-center py-20">
          <span className="text-5xl mb-4">📊</span>
          <p className="text-gray-500 font-medium">Bado hakuna data</p>
        </div>
      ) : (
        <>
          {/* Podium */}
          {top3.length >= 3 && (
            <div className="flex items-end justify-center gap-4 mb-8 px-4">
              {/* 2nd */}
              <div className="flex flex-col items-center flex-1">
                <span className="text-2xl mb-1">⚡</span>
                <div className="w-full bg-gray-100 rounded-t-2xl pt-4 pb-3 text-center">
                  <p className="font-bold text-sm text-gray-700">{top3[1]?.profile?.username}</p>
                  <p className="text-xs text-gray-400">{top3[1]?.points?.toLocaleString()} pts</p>
                </div>
                <div className="w-full bg-gray-300 rounded-b-lg h-12 flex items-center justify-center">
                  <span className="text-2xl">🥈</span>
                </div>
              </div>

              {/* 1st */}
              <div className="flex flex-col items-center flex-1">
                <span className="text-3xl mb-1">{SKULLS[0]}</span>
                <p className="font-extrabold text-sm text-[#FF6B00] mb-1">{top3[0]?.profile?.username}</p>
                <p className="text-xs text-gray-500 mb-1">{top3[0]?.points?.toLocaleString()} pts</p>
                <div className="w-full bg-[#FFD700]/20 rounded-t-2xl pt-4 pb-3 text-center border-2 border-[#FFD700]">
                  <div className="w-full h-16 flex items-center justify-center">
                    <span className="text-3xl">🥇</span>
                  </div>
                </div>
              </div>

              {/* 3rd */}
              <div className="flex flex-col items-center flex-1">
                <span className="text-2xl mb-1">👑</span>
                <div className="w-full bg-gray-100 rounded-t-2xl pt-4 pb-3 text-center">
                  <p className="font-bold text-sm text-gray-700">{top3[2]?.profile?.username}</p>
                  <p className="text-xs text-gray-400">{top3[2]?.points?.toLocaleString()} pts</p>
                </div>
                <div className="w-full bg-orange-200 rounded-b-lg h-8 flex items-center justify-center">
                  <span className="text-2xl">🥉</span>
                </div>
              </div>
            </div>
          )}

          {/* Rest of leaderboard */}
          <div className="space-y-3">
            {rest.map((entry, index) => {
              const rank = index + 4
              const isMe = entry.profile?.username === profile?.username
              const icon = SKULLS[rank % SKULLS.length]

              return (
                <div
                  key={entry.id}
                  className={`card flex items-center gap-3 ${isMe ? 'border-[#00C853] border-2' : ''}`}
                >
                  <span className="text-gray-400 font-bold text-sm w-5 text-center">{rank}</span>
                  <span className="text-xl">{icon}</span>
                  <div className="flex-1">
                    <p className={`font-bold text-sm ${isMe ? 'text-[#00C853]' : 'text-gray-900'}`}>
                      {entry.profile?.username}
                      {isMe && ' (Wewe)'}
                    </p>
                    <p className="text-xs text-gray-400">
                      {entry.profile?.total_wins}W · {entry.profile?.total_games} mechi · {formatTZS(entry.profile?.total_earnings ?? 0)}
                    </p>
                  </div>
                  <span className="font-bold text-[#00C853] text-sm">{entry.points?.toLocaleString()}</span>
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}
