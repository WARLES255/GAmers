import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { Bell, Globe, HelpCircle, Share2, Moon, LogOut, ChevronRight, ArrowDownCircle, ArrowUpCircle } from 'lucide-react'

function formatTZS(n) {
  return new Intl.NumberFormat('sw-TZ').format(n ?? 0)
}

export default function Profaili() {
  const { profile, signOut, refreshProfile } = useAuth()
  const navigate = useNavigate()
  const [transactions, setTransactions] = useState([])
  const [myTournaments, setMyTournaments] = useState([])
  const [tournamentTab, setTournamentTab] = useState('joined')
  const [showDepositModal, setShowDepositModal] = useState(false)
  const [showWithdrawModal, setShowWithdrawModal] = useState(false)

  useEffect(() => {
    if (!profile) return
    fetchTransactions()
    fetchMyTournaments()
  }, [profile, tournamentTab])

  async function fetchTransactions() {
    const { data } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false })
      .limit(10)
    setTransactions(data ?? [])
  }

  async function fetchMyTournaments() {
    if (tournamentTab === 'joined') {
      const { data } = await supabase
        .from('tournament_participants')
        .select('tournament:tournaments(*)')
        .eq('user_id', profile.id)
        .order('joined_at', { ascending: false })
      setMyTournaments(data?.map(d => d.tournament) ?? [])
    } else {
      const { data } = await supabase
        .from('tournaments')
        .select('*')
        .eq('created_by', profile.id)
        .order('created_at', { ascending: false })
      setMyTournaments(data ?? [])
    }
  }

  async function handleSignOut() {
    await signOut()
    navigate('/login')
  }

  const settings = [
    { icon: Bell, label: 'Notifications', action: () => {} },
    { icon: Globe, label: 'Language (SW/EN)', action: () => {} },
    { icon: HelpCircle, label: 'Help & Support', action: () => {} },
    { icon: Share2, label: 'Shiriki App', action: () => {} },
    { icon: Moon, label: 'Giza (Dark)', action: () => {} },
  ]

  return (
    <div className="px-4 pt-6 pb-6">
      {/* Avatar + stats */}
      <div className="flex flex-col items-center mb-6">
        <div className="w-20 h-20 rounded-full bg-gray-100 border-4 border-[#00C853] flex items-center justify-center text-4xl mb-3">
          🎮
        </div>
        <h2 className="text-xl font-extrabold flex items-center gap-2">
          {profile?.username}
          <span className="text-[#00C853]">🛡️</span>
        </h2>
        <p className="text-sm text-gray-400">{profile?.city ?? 'Dar es Salaam'}, TZ 🇹🇿</p>
        <p className="text-xs text-gray-300 mt-0.5">
          Mwanachama tangu {new Date(profile?.created_at).toLocaleDateString('sw-TZ', { month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-2 mb-6">
        {[
          { label: 'Michezo', value: profile?.total_games ?? 0 },
          { label: 'Ushindi', value: profile?.total_wins ?? 0 },
          { label: 'Win Rate', value: profile?.total_games ? `${Math.round((profile.total_wins / profile.total_games) * 100)}%` : '0%' },
          { label: 'Mapato', value: `TZS ${formatTZS(profile?.total_earnings ?? 0)}`, small: true },
        ].map((s) => (
          <div key={s.label} className="card text-center py-3 px-1">
            <p className={`font-extrabold text-[#00C853] ${s.small ? 'text-xs' : 'text-lg'}`}>{s.value}</p>
            <p className="text-[10px] text-gray-400 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Wallet */}
      <div className="card mb-5">
        <h3 className="font-bold text-base mb-3 flex items-center gap-2">Mkoba Wangu 💰</h3>
        <div className="mb-3">
          <p className="text-xs text-gray-400 mb-1">Salio</p>
          <p className="text-3xl font-extrabold text-[#00C853]">TZS {formatTZS(profile?.wallet_balance)}</p>
        </div>

        <div className="flex gap-3 mb-4">
          <button
            onClick={() => setShowDepositModal(true)}
            className="flex-1 bg-[#00C853] text-white font-bold py-3 rounded-xl text-sm active:scale-95 transition-transform"
          >
            ONGEZA PESA
          </button>
          <button
            onClick={() => setShowWithdrawModal(true)}
            className="flex-1 border-2 border-gray-200 text-gray-700 font-bold py-3 rounded-xl text-sm active:scale-95 transition-transform"
          >
            TOA PESA
          </button>
        </div>

        {/* Recent transactions */}
        {transactions.slice(0, 3).map(tx => (
          <div key={tx.id} className="flex items-center gap-3 py-2 border-t border-gray-50">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.amount > 0 ? 'bg-green-50' : 'bg-red-50'}`}>
              {tx.type === 'entry_fee' ? '⚽' :
               tx.type === 'prize' ? '🏆' :
               tx.type === 'deposit' ? '➕' : '➖'}
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold text-gray-700">{tx.description}</p>
              <p className="text-[10px] text-gray-400">{new Date(tx.created_at).toLocaleDateString('sw-TZ')}</p>
            </div>
            <span className={`text-sm font-bold ${tx.amount > 0 ? 'text-[#00C853]' : 'text-red-500'}`}>
              {tx.amount > 0 ? '+' : ''}TZS {formatTZS(Math.abs(tx.amount))}
            </span>
          </div>
        ))}
      </div>

      {/* My Tournaments */}
      <div className="mb-5">
        <h3 className="font-bold text-base mb-3">Tournaments Zangu</h3>
        <div className="flex gap-2 mb-3">
          {[['joined', 'Nimejoin'], ['created', 'Nimeunda']].map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTournamentTab(key)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all ${
                tournamentTab === key ? 'bg-[#00C853] text-white' : 'bg-white text-gray-500 border border-gray-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        {myTournaments.length === 0 ? (
          <p className="text-sm text-gray-400 py-4 text-center">Hakuna tournaments bado</p>
        ) : (
          myTournaments.map(t => (
            <div
              key={t.id}
              className="card mb-2 flex items-center gap-3 cursor-pointer active:scale-[0.98] transition-transform"
              onClick={() => navigate(`/tournament/${t.id}`)}
            >
              <span className="text-2xl">⚽</span>
              <div>
                <p className="font-bold text-sm">{t.title}</p>
                <p className="text-xs text-gray-400">{t.game} · <span className="text-[#FF6B00]">TZS {formatTZS(t.prize_pool)}</span></p>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Settings */}
      <div className="space-y-2 mb-4">
        {settings.map(({ icon: Icon, label, action }) => (
          <button
            key={label}
            onClick={action}
            className="card w-full flex items-center gap-3 active:scale-[0.98] transition-transform"
          >
            <Icon size={18} className="text-gray-500" />
            <span className="flex-1 text-left text-sm font-medium">{label}</span>
            <ChevronRight size={16} className="text-gray-300" />
          </button>
        ))}
      </div>

      {/* Logout */}
      <button
        onClick={handleSignOut}
        className="card w-full flex items-center gap-3 border-red-100 active:scale-[0.98] transition-transform"
      >
        <LogOut size={18} className="text-red-500" />
        <span className="text-red-500 font-semibold text-sm">Ondoka</span>
      </button>

      {/* Deposit Modal */}
      {showDepositModal && (
        <DepositModal onClose={() => { setShowDepositModal(false); refreshProfile() }} profile={profile} />
      )}

      {/* Withdraw Modal */}
      {showWithdrawModal && (
        <WithdrawModal onClose={() => { setShowWithdrawModal(false); refreshProfile() }} profile={profile} />
      )}
    </div>
  )
}

function DepositModal({ onClose, profile }) {
  const [amount, setAmount] = useState('')
  const [phone, setPhone] = useState(profile?.phone ?? '')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const QUICK_AMOUNTS = [1000, 2000, 5000, 10000, 20000, 50000]

  async function handleDeposit() {
    if (!amount || amount < 500) return
    setLoading(true)

    // TODO: Integrate Selcom push payment API here
    // For now, simulate a successful deposit (demo mode)
    await new Promise(r => setTimeout(r, 1500))

    // Update wallet balance in Supabase
    const { error } = await supabase.rpc('add_wallet_balance', {
      user_id: profile.id,
      amount: parseInt(amount),
      description: 'Amana ya pesa'
    })

    if (!error) setSuccess(true)
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-6 pb-10" onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />
        <h3 className="text-xl font-extrabold mb-5">Ongeza Pesa 💰</h3>

        {success ? (
          <div className="text-center py-8">
            <div className="text-5xl mb-3">✅</div>
            <p className="font-bold text-lg text-[#00C853]">Imefanikiwa!</p>
            <p className="text-gray-400 text-sm mt-1">Pesa imeongezwa kwenye mkoba wako</p>
            <button onClick={onClose} className="btn-primary mt-5 w-full">Funga</button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-3 gap-2 mb-4">
              {QUICK_AMOUNTS.map(a => (
                <button
                  key={a}
                  onClick={() => setAmount(String(a))}
                  className={`py-2.5 rounded-xl text-sm font-bold border-2 transition-all ${
                    amount === String(a) ? 'border-[#00C853] bg-green-50 text-[#00C853]' : 'border-gray-100 text-gray-600'
                  }`}
                >
                  {new Intl.NumberFormat('sw-TZ').format(a)}
                </button>
              ))}
            </div>

            <input
              type="number"
              placeholder="Au ingiza kiasi chako (TZS)"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm font-medium focus:outline-none focus:border-[#00C853] mb-3"
            />
            <input
              type="tel"
              placeholder="Namba ya simu (M-Pesa/Tigo/Airtel)"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm font-medium focus:outline-none focus:border-[#00C853] mb-5"
            />

            <button
              onClick={handleDeposit}
              disabled={loading || !amount}
              className="btn-primary w-full disabled:opacity-50"
            >
              {loading ? 'Inasubiri...' : `LIPA TZS ${amount ? new Intl.NumberFormat('sw-TZ').format(amount) : '0'}`}
            </button>
          </>
        )}
      </div>
    </div>
  )
}

function WithdrawModal({ onClose, profile }) {
  const [amount, setAmount] = useState('')
  const [phone, setPhone] = useState(profile?.phone ?? '')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  async function handleWithdraw() {
    if (!amount || amount < 500 || amount > profile.wallet_balance) return
    setLoading(true)
    await new Promise(r => setTimeout(r, 1500))
    // TODO: Selcom payout API
    setSuccess(true)
    setLoading(false)
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end" onClick={onClose}>
      <div className="bg-white w-full max-w-[480px] mx-auto rounded-t-3xl p-6 pb-10" onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />
        <h3 className="text-xl font-extrabold mb-1">Toa Pesa</h3>
        <p className="text-sm text-gray-400 mb-5">Salio: TZS {new Intl.NumberFormat('sw-TZ').format(profile?.wallet_balance ?? 0)}</p>

        {success ? (
          <div className="text-center py-8">
            <div className="text-5xl mb-3">✅</div>
            <p className="font-bold text-lg text-[#00C853]">Ombi limetumwa!</p>
            <p className="text-gray-400 text-sm mt-1">Pesa itafikia simu yako ndani ya dakika chache</p>
            <button onClick={onClose} className="btn-primary mt-5 w-full">Funga</button>
          </div>
        ) : (
          <>
            <input
              type="number"
              placeholder="Kiasi cha kutoa (TZS)"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm font-medium focus:outline-none focus:border-[#00C853] mb-3"
            />
            <input
              type="tel"
              placeholder="Namba ya simu ya kupokea"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm font-medium focus:outline-none focus:border-[#00C853] mb-5"
            />
            <button
              onClick={handleWithdraw}
              disabled={loading || !amount || parseInt(amount) > profile?.wallet_balance}
              className="btn-outline w-full disabled:opacity-50"
            >
              {loading ? 'Inatuma...' : 'TOA PESA'}
            </button>
          </>
        )}
      </div>
    </div>
  )
}
