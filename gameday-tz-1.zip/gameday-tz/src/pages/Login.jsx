import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleLogin() {
    if (!phone || !password) return
    setLoading(true)
    setError('')
    const { error } = await signIn({ phone: `+255${phone.replace(/^0/, '')}`, password })
    if (error) setError('Namba ya simu au neno la siri halikufaa')
    setLoading(false)
  }

  return (
    <div className="min-h-screen bg-white flex flex-col px-6 pt-16 pb-10">
      {/* Logo */}
      <div className="flex flex-col items-center mb-12">
        <div className="w-20 h-20 rounded-3xl bg-[#00C853] flex items-center justify-center mb-4 shadow-lg shadow-green-200">
          <span className="text-4xl">🎮</span>
        </div>
        <h1 className="text-3xl font-extrabold text-gray-900">GameDay TZ</h1>
        <p className="text-gray-400 text-sm mt-1">Shindana. Shinda. Jibu.</p>
      </div>

      <div className="space-y-4 mb-6">
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Namba ya Simu</label>
          <div className="flex items-center border-2 border-gray-100 rounded-xl overflow-hidden focus-within:border-[#00C853]">
            <span className="px-3 py-3.5 bg-gray-50 text-sm font-semibold text-gray-500 border-r border-gray-100">+255</span>
            <input
              type="tel"
              placeholder="712 345 678"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              className="flex-1 px-3 py-3.5 text-sm font-medium focus:outline-none"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-gray-500 uppercase mb-1.5 block">Neno la Siri</label>
          <input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleLogin()}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        {error && (
          <p className="text-red-500 text-sm text-center bg-red-50 py-2 rounded-xl">{error}</p>
        )}

        <button
          onClick={handleLogin}
          disabled={loading || !phone || !password}
          className="w-full bg-[#00C853] text-white font-extrabold py-4 rounded-xl text-base disabled:opacity-50 active:scale-95 transition-transform"
        >
          {loading ? 'Inaingia...' : 'INGIA'}
        </button>
      </div>

      <p className="text-center text-sm text-gray-400">
        Huna akaunti?{' '}
        <button onClick={() => navigate('/register')} className="text-[#00C853] font-bold">
          Jisajili hapa
        </button>
      </p>
    </div>
  )
}
