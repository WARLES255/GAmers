import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { Swords } from 'lucide-react'

function MatchCard({ match }) {
  const { profile } = useAuth()
  const isPlayer1 = match.player1_id === profile?.id
  const opponent = isPlayer1 ? match.player2 : match.player1
  const myScore = isPlayer1 ? match.player1_score : match.player2_score
  const theirScore = isPlayer1 ? match.player2_score : match.player1_score
  const won = match.winner_id === profile?.id

  return (
    <div className="card mb-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-gray-400">{match.tournament?.title ?? 'Tournament'}</span>
        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
          match.status === 'live' ? 'bg-green-50 text-[#00C853]' :
          match.status === 'completed' ? (won ? 'bg-blue-50 text-blue-600' : 'bg-red-50 text-red-500') :
          'bg-gray-100 text-gray-500'
        }`}>
          {match.status === 'live' ? 'LIVE' : match.status === 'completed' ? (won ? 'UMESHINDA' : 'UMEPOTEZA') : 'INANGOJEA'}
        </span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-[#00C853]/10 flex items-center justify-center text-sm font-bold text-[#00C853]">
            {profile?.username?.[0]?.toUpperCase() ?? 'U'}
          </div>
          <span className="font-bold text-sm">{profile?.username}</span>
        </div>

        <div className="flex items-center gap-2">
          {match.status === 'completed' && (
            <span className="font-bold text-lg">{myScore ?? '-'} : {theirScore ?? '-'}</span>
          )}
          {match.status === 'live' && (
            <span className="font-bold text-[#00C853] text-lg animate-pulse">VS</span>
          )}
          {match.status === 'pending' && (
            <span className="font-bold text-gray-400 text-lg">VS</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="font-bold text-sm">{opponent?.username ?? '???'}</span>
          <div className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-sm font-bold text-gray-500">
            {opponent?.username?.[0]?.toUpperCase() ?? '?'}
          </div>
        </div>
      </div>

      {match.status === 'live' && (
        <button className="w-full mt-3 bg-[#00C853] text-white font-bold py-2.5 rounded-xl text-sm">
          TAZAMA MECHI
        </button>
      )}

      {match.status === 'pending' && (
        <button className="w-full mt-3 border border-[#00C853] text-[#00C853] font-bold py-2.5 rounded-xl text-sm">
          WASILIANA NA MPINZANI
        </button>
      )}
    </div>
  )
}

export default function Mechi() {
  const { profile } = useAuth()
  const [activeTab, setActiveTab] = useState('ongoing')
  const [matches, setMatches] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!profile) return
    fetchMatches()
  }, [profile, activeTab])

  async function fetchMatches() {
    setLoading(true)
    const statusFilter = activeTab === 'ongoing' ? ['pending', 'live'] : ['completed']

    const { data } = await supabase
      .from('matches')
      .select(`
        *,
        tournament:tournaments(title, game),
        player1:profiles!matches_player1_id_fkey(username),
        player2:profiles!matches_player2_id_fkey(username)
      `)
      .or(`player1_id.eq.${profile.id},player2_id.eq.${profile.id}`)
      .in('status', statusFilter)
      .order('created_at', { ascending: false })

    setMatches(data ?? [])
    setLoading(false)
  }

  return (
    <div className="px-4 pt-6">
      <h1 className="text-2xl font-extrabold mb-4 flex items-center gap-2">
        Mechi Zangu <span>⚔️</span>
      </h1>

      {/* Tabs */}
      <div className="flex gap-2 mb-5">
        <button
          onClick={() => setActiveTab('ongoing')}
          className={`px-5 py-2 rounded-full font-semibold text-sm transition-all ${
            activeTab === 'ongoing' ? 'bg-[#00C853] text-white' : 'bg-white text-gray-500 border border-gray-200'
          }`}
        >
          Inayoendelea
        </button>
        <button
          onClick={() => setActiveTab('finished')}
          className={`px-5 py-2 rounded-full font-semibold text-sm transition-all ${
            activeTab === 'finished' ? 'bg-[#00C853] text-white' : 'bg-white text-gray-500 border border-gray-200'
          }`}
        >
          Iliyokwisha
        </button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1,2].map(i => <div key={i} className="h-28 bg-gray-100 rounded-2xl animate-pulse" />)}
        </div>
      ) : matches.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Swords size={48} className="text-gray-200 mb-4" />
          <p className="font-semibold text-gray-500">Huna mechi {activeTab === 'ongoing' ? 'inayoendelea' : 'iliyokwisha'}</p>
          <p className="text-sm text-gray-400 mt-1">Jiunga na tournament kupata mechi!</p>
        </div>
      ) : (
        matches.map(m => <MatchCard key={m.id} match={m} />)
      )}
    </div>
  )
}
