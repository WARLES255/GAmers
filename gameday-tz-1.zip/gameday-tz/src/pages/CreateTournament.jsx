import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { ArrowLeft } from 'lucide-react'

const GAMES = ['eFootball', 'Free Fire', 'Asphalt 9', 'Mortal Kombat', 'PUBG Mobile', 'COD Mobile', 'FIFA', 'Chess', 'Nyingine']
const MAX_SIZES = [2, 4, 8, 16, 32]
const ENTRY_FEES = [500, 1000, 1500, 2000, 5000, 10000]

export default function CreateTournament() {
  const { profile } = useAuth()
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    title: '',
    game: '',
    entry_fee: 1000,
    max_participants: 8,
    rules: '',
    bracket_type: 'single_elimination',
    starts_at: '',
  })

  const prize_pool = form.entry_fee * form.max_participants * 0.9 // 10% platform fee

  function update(field, value) {
    setForm(prev => ({ ...prev, [field]: value }))
  }

  async function handleCreate() {
    if (!form.title || !form.game) {
      alert('Tafadhali jaza jina na mchezo')
      return
    }

    setLoading(true)

    const { data, error } = await supabase
      .from('tournaments')
      .insert({
        title: form.title,
        game: form.game,
        entry_fee: form.entry_fee,
        max_participants: form.max_participants,
        prize_pool: Math.round(prize_pool),
        rules: form.rules,
        bracket_type: form.bracket_type,
        starts_at: form.starts_at || null,
        created_by: profile.id,
        status: 'open',
      })
      .select()
      .single()

    if (error) {
      alert('Hitilafu imetokea: ' + error.message)
    } else {
      navigate(`/tournament/${data.id}`)
    }

    setLoading(false)
  }

  return (
    <div className="px-4 pt-4 pb-10">
      <button
        onClick={() => navigate(-1)}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center mb-4 active:scale-90 transition-transform"
      >
        <ArrowLeft size={18} />
      </button>

      <h1 className="text-2xl font-extrabold mb-6">Unda Tournament 🏆</h1>

      <div className="space-y-5">
        {/* Title */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Jina la Tournament *</label>
          <input
            type="text"
            placeholder="Mfano: Dar Open Weekend"
            value={form.title}
            onChange={e => update('title', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3.5 text-sm font-medium focus:outline-none focus:border-[#00C853]"
          />
        </div>

        {/* Game */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Mchezo *</label>
          <div className="grid grid-cols-3 gap-2">
            {GAMES.map(g => (
              <button
                key={g}
                onClick={() => update('game', g)}
                className={`py-2.5 px-2 rounded-xl text-xs font-semibold border-2 transition-all ${
                  form.game === g ? 'border-[#00C853] bg-green-50 text-[#00C853]' : 'border-gray-100 text-gray-600'
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>

        {/* Entry fee */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Ada ya Kuingia (TZS)</label>
          <div className="grid grid-cols-3 gap-2 mb-2">
            {ENTRY_FEES.map(f => (
              <button
                key={f}
                onClick={() => update('entry_fee', f)}
                className={`py-2.5 rounded-xl text-xs font-bold border-2 transition-all ${
                  form.entry_fee === f ? 'border-[#00C853] bg-green-50 text-[#00C853]' : 'border-gray-100 text-gray-600'
                }`}
              >
                {new Intl.NumberFormat('sw-TZ').format(f)}
              </button>
            ))}
          </div>
          <input
            type="number"
            placeholder="Au ingiza kiasi kingine"
            value={ENTRY_FEES.includes(form.entry_fee) ? '' : form.entry_fee}
            onChange={e => update('entry_fee', parseInt(e.target.value) || 0)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#00C853]"
          />
        </div>

        {/* Max participants */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Idadi ya Washiriki</label>
          <div className="flex gap-2">
            {MAX_SIZES.map(s => (
              <button
                key={s}
                onClick={() => update('max_participants', s)}
                className={`flex-1 py-2.5 rounded-xl text-sm font-bold border-2 transition-all ${
                  form.max_participants === s ? 'border-[#00C853] bg-green-50 text-[#00C853]' : 'border-gray-100 text-gray-600'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Prize pool preview */}
        <div className="bg-gradient-to-r from-[#1a3a2a] to-[#2d5a3d] rounded-2xl p-4">
          <p className="text-white/60 text-xs mb-1">Tuzo ya jumla (90%)</p>
          <p className="text-[#FF6B00] font-extrabold text-2xl">
            TZS {new Intl.NumberFormat('sw-TZ').format(Math.round(prize_pool))}
          </p>
          <p className="text-white/40 text-xs mt-1">
            {form.entry_fee} × {form.max_participants} washiriki × 90%
          </p>
        </div>

        {/* Bracket type */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Aina ya Bracket</label>
          <div className="flex gap-2">
            {[['single_elimination', 'Single Elim'], ['double_elimination', 'Double Elim'], ['round_robin', 'Round Robin']].map(([val, label]) => (
              <button
                key={val}
                onClick={() => update('bracket_type', val)}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold border-2 transition-all ${
                  form.bracket_type === val ? 'border-[#00C853] bg-green-50 text-[#00C853]' : 'border-gray-100 text-gray-600'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Start time */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Wakati wa Kuanza (hiari)</label>
          <input
            type="datetime-local"
            value={form.starts_at}
            onChange={e => update('starts_at', e.target.value)}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#00C853]"
          />
        </div>

        {/* Rules */}
        <div>
          <label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block">Sheria (hiari)</label>
          <textarea
            placeholder="Andika sheria za mchezo wako..."
            value={form.rules}
            onChange={e => update('rules', e.target.value)}
            rows={3}
            className="w-full border-2 border-gray-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#00C853] resize-none"
          />
        </div>

        <button
          onClick={handleCreate}
          disabled={loading || !form.title || !form.game}
          className="w-full bg-[#00C853] text-white font-extrabold py-4 rounded-xl text-base tracking-wide disabled:opacity-50 active:scale-95 transition-transform"
        >
          {loading ? 'Inaunda...' : 'UNDA TOURNAMENT'}
        </button>
      </div>
    </div>
  )
}
