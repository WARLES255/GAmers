import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import TournamentCard from '../components/tournaments/TournamentCard'

const FILTERS = ['Zote', 'Live', 'Inaanza', 'eFootball', 'COD Mobile', 'Free Fire', 'Asphalt 9']

export default function Home() {
  const [tournaments, setTournaments] = useState([])
  const [activeFilter, setActiveFilter] = useState('Zote')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchTournaments()

    // Realtime subscription
    const channel = supabase
      .channel('tournaments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tournaments' }, () => {
        fetchTournaments()
      })
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [activeFilter])

  async function fetchTournaments() {
    setLoading(true)
    let query = supabase
      .from('tournaments')
      .select('*')
      .order('created_at', { ascending: false })

    if (activeFilter === 'Live') query = query.eq('status', 'live')
    else if (activeFilter === 'Inaanza') query = query.eq('status', 'open')
    else if (activeFilter !== 'Zote') query = query.eq('game', activeFilter)

    const { data } = await query
    setTournaments(data ?? [])
    setLoading(false)
  }

  const featured = tournaments[0]
  const rest = tournaments.slice(1)

  return (
    <div className="px-4 pt-4">
      {/* Filter tabs */}
      <div className="flex gap-2 overflow-x-auto pb-3 -mx-4 px-4 scrollbar-hide mb-4">
        {FILTERS.map(filter => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-all ${
              activeFilter === filter
                ? 'bg-[#00C853] text-white'
                : 'bg-white text-gray-500 border border-gray-200'
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => (
            <div key={i} className="h-24 bg-gray-100 rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : tournaments.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <span className="text-5xl mb-4">🎮</span>
          <p className="text-gray-500 font-medium">Hakuna tournaments bado</p>
          <p className="text-gray-400 text-sm mt-1">Unda tournament mpya!</p>
        </div>
      ) : (
        <>
          {featured && <TournamentCard tournament={featured} featured />}
          {rest.map(t => <TournamentCard key={t.id} tournament={t} />)}
        </>
      )}
    </div>
  )
}
