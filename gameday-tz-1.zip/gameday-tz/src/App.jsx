import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './context/AuthContext'
import BottomNav from './components/layout/BottomNav'
import TopBar from './components/layout/TopBar'
import Home from './pages/Home'
import Mechi from './pages/Mechi'
import Bodi from './pages/Bodi'
import Profaili from './pages/Profaili'
import Login from './pages/Login'
import Register from './pages/Register'
import TournamentDetail from './pages/TournamentDetail'
import CreateTournament from './pages/CreateTournament'

function AppInner() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full border-4 border-[#00C853] border-t-transparent animate-spin" />
          <p className="text-sm text-gray-400 font-medium">Inapakia...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#F5F5F5]">
      <TopBar />
      <main className="flex-1 pb-nav overflow-y-auto">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/mechi" element={<Mechi />} />
          <Route path="/bodi" element={<Bodi />} />
          <Route path="/profaili" element={<Profaili />} />
          <Route path="/tournament/:id" element={<TournamentDetail />} />
          <Route path="/tournament/create" element={<CreateTournament />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <BottomNav />
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppInner />
      </BrowserRouter>
    </AuthProvider>
  )
}
