# GameDay TZ 🎮

**Mobile-first gaming tournament platform for Tanzania**

Stack: React + Vite + Supabase + Vercel + Tailwind CSS

---

## Tech Stack

| Layer | Tool | Why |
|-------|------|-----|
| Frontend | React + Vite | Fast, modern, easy to update |
| Styling | Tailwind CSS | Mobile-first, fast UI |
| Backend/DB | Supabase | Postgres + Auth + Storage + Realtime |
| Payments | Selcom API | M-Pesa / TZS payments |
| Hosting | Vercel | Free, auto-deploy from GitHub |
| Version Control | GitHub | Push to deploy |

---

## Project Structure

```
gameday-tz/
├── src/
│   ├── components/
│   │   ├── layout/
│   │   │   ├── BottomNav.jsx
│   │   │   └── TopBar.jsx
│   │   ├── tournaments/
│   │   │   ├── TournamentCard.jsx
│   │   │   ├── TournamentList.jsx
│   │   │   └── TournamentFilters.jsx
│   │   ├── wallet/
│   │   │   ├── WalletCard.jsx
│   │   │   └── TransactionItem.jsx
│   │   ├── leaderboard/
│   │   │   └── LeaderboardPodium.jsx
│   │   └── ui/
│   │       ├── Button.jsx
│   │       ├── Badge.jsx
│   │       └── Avatar.jsx
│   ├── pages/
│   │   ├── Home.jsx          (Tournaments tab)
│   │   ├── Mechi.jsx         (My Matches tab)
│   │   ├── Bodi.jsx          (Leaderboard tab)
│   │   └── Profaili.jsx      (Profile tab)
│   ├── hooks/
│   │   ├── useTournaments.js
│   │   ├── useWallet.js
│   │   └── useAuth.js
│   ├── lib/
│   │   ├── supabase.js       (Supabase client)
│   │   └── selcom.js         (Payment API)
│   ├── context/
│   │   └── AuthContext.jsx
│   └── App.jsx
├── supabase/
│   └── migrations/
│       └── 001_initial_schema.sql
├── .env.example
├── package.json
└── vercel.json
```

---

## Quick Deploy

### 1. Clone & Install
```bash
git clone https://github.com/YOUR_USERNAME/gameday-tz
cd gameday-tz
npm install
```

### 2. Supabase Setup
1. Go to supabase.com → New Project
2. Run `supabase/migrations/001_initial_schema.sql` in SQL editor
3. Copy your Project URL and anon key

### 3. Environment Variables
```bash
cp .env.example .env.local
# Fill in your Supabase + Selcom credentials
```

### 4. Deploy to Vercel
```bash
# Option A: Via CLI
npx vercel

# Option B: Connect GitHub repo on vercel.com (recommended)
# Every git push = auto deploy
```

---

## Supabase Tables

- `profiles` — user accounts, wallet balance, stats
- `tournaments` — all tournaments
- `tournament_participants` — who joined what
- `matches` — match results
- `transactions` — wallet in/out history
- `leaderboard_points` — weekly/monthly/all-time points

---

## Update Workflow

```
Edit code → git add . → git commit -m "fix" → git push → Vercel auto-deploys
```
Takes ~60 seconds from push to live.
