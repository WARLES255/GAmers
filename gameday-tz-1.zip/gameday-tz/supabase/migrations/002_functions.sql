-- Add these functions to your Supabase SQL Editor

-- Function: join_tournament (atomic: deduct fee + add participant + update prize pool)
CREATE OR REPLACE FUNCTION join_tournament(
  p_tournament_id UUID,
  p_user_id UUID,
  p_entry_fee BIGINT
)
RETURNS void AS $$
DECLARE
  v_balance BIGINT;
  v_current_participants INTEGER;
  v_max_participants INTEGER;
BEGIN
  -- Lock the user's profile row
  SELECT wallet_balance INTO v_balance
  FROM profiles WHERE id = p_user_id FOR UPDATE;

  -- Check sufficient balance
  IF v_balance < p_entry_fee THEN
    RAISE EXCEPTION 'Insufficient balance';
  END IF;

  -- Check tournament capacity
  SELECT current_participants, max_participants
  INTO v_current_participants, v_max_participants
  FROM tournaments WHERE id = p_tournament_id FOR UPDATE;

  IF v_current_participants >= v_max_participants THEN
    RAISE EXCEPTION 'Tournament is full';
  END IF;

  -- Deduct entry fee
  UPDATE profiles
  SET wallet_balance = wallet_balance - p_entry_fee
  WHERE id = p_user_id;

  -- Add participant
  INSERT INTO tournament_participants (tournament_id, user_id)
  VALUES (p_tournament_id, p_user_id);

  -- Increment participant count
  UPDATE tournaments
  SET
    current_participants = current_participants + 1,
    prize_pool = prize_pool + ROUND(p_entry_fee * 0.9)
  WHERE id = p_tournament_id;

  -- Record transaction
  INSERT INTO transactions (user_id, type, amount, description, tournament_id)
  VALUES (p_user_id, 'entry_fee', -p_entry_fee, 'Kuingia - ' || (SELECT title FROM tournaments WHERE id = p_tournament_id), p_tournament_id);

END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- Function: add_wallet_balance (for deposits)
CREATE OR REPLACE FUNCTION add_wallet_balance(
  user_id UUID,
  amount BIGINT,
  description TEXT DEFAULT 'Amana'
)
RETURNS void AS $$
BEGIN
  UPDATE profiles
  SET wallet_balance = wallet_balance + amount
  WHERE id = user_id;

  INSERT INTO transactions (user_id, type, amount, description)
  VALUES (user_id, 'deposit', amount, description);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;


-- Function: award_prize (call when tournament ends)
CREATE OR REPLACE FUNCTION award_prize(
  p_tournament_id UUID,
  p_winner_id UUID,
  p_amount BIGINT,
  p_position INTEGER
)
RETURNS void AS $$
BEGIN
  UPDATE profiles
  SET
    wallet_balance = wallet_balance + p_amount,
    total_earnings = total_earnings + p_amount,
    total_wins = CASE WHEN p_position = 1 THEN total_wins + 1 ELSE total_wins END
  WHERE id = p_winner_id;

  INSERT INTO transactions (user_id, type, amount, description, tournament_id)
  VALUES (p_winner_id, 'prize', p_amount, 'Tuzo - ' || p_position || ' mahali', p_tournament_id);

  UPDATE tournament_participants
  SET final_position = p_position, prize_won = p_amount
  WHERE tournament_id = p_tournament_id AND user_id = p_winner_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
