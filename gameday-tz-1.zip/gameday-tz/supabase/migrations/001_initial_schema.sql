-- GameDay TZ Database Schema
-- Run this in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================
-- PROFILES TABLE
-- =====================
CREATE TABLE profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  full_name TEXT,
  phone TEXT UNIQUE,
  city TEXT DEFAULT 'Dar es Salaam',
  avatar_url TEXT,
  wallet_balance BIGINT DEFAULT 0,  -- stored in TZS cents (multiply by 100)
  total_games INTEGER DEFAULT 0,
  total_wins INTEGER DEFAULT 0,
  total_earnings BIGINT DEFAULT 0,
  is_verified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- TOURNAMENTS TABLE
-- =====================
CREATE TABLE tournaments (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  game TEXT NOT NULL,                    -- 'eFootball', 'Free Fire', 'Asphalt 9', etc.
  game_icon TEXT,                        -- emoji or icon url
  prize_pool BIGINT NOT NULL,            -- TZS
  entry_fee BIGINT NOT NULL,             -- TZS
  max_participants INTEGER NOT NULL,
  current_participants INTEGER DEFAULT 0,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'live', 'completed', 'cancelled')),
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  created_by UUID REFERENCES profiles(id),
  rules TEXT,
  bracket_type TEXT DEFAULT 'single_elimination',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- TOURNAMENT PARTICIPANTS
-- =====================
CREATE TABLE tournament_participants (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tournament_id UUID REFERENCES tournaments(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  final_position INTEGER,
  prize_won BIGINT DEFAULT 0,
  UNIQUE(tournament_id, user_id)
);

-- =====================
-- MATCHES TABLE
-- =====================
CREATE TABLE matches (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  tournament_id UUID REFERENCES tournaments(id) ON DELETE CASCADE,
  player1_id UUID REFERENCES profiles(id),
  player2_id UUID REFERENCES profiles(id),
  winner_id UUID REFERENCES profiles(id),
  player1_score INTEGER,
  player2_score INTEGER,
  round INTEGER,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'live', 'completed', 'disputed')),
  scheduled_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- WALLET TRANSACTIONS
-- =====================
CREATE TABLE transactions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('deposit', 'withdrawal', 'entry_fee', 'prize', 'refund')),
  amount BIGINT NOT NULL,               -- TZS (positive = credit, negative = debit)
  description TEXT,
  reference TEXT,                       -- Selcom reference
  status TEXT DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'failed')),
  tournament_id UUID REFERENCES tournaments(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =====================
-- LEADERBOARD POINTS
-- =====================
CREATE TABLE leaderboard_points (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  points INTEGER DEFAULT 0,
  week_number INTEGER,
  month_number INTEGER,
  year INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, week_number, month_number, year)
);

-- =====================
-- ROW LEVEL SECURITY
-- =====================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE tournament_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE leaderboard_points ENABLE ROW LEVEL SECURITY;

-- Profiles: anyone can read, only owner can update
CREATE POLICY "Public profiles are viewable by everyone" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- Tournaments: everyone can read, authenticated can create
CREATE POLICY "Tournaments are viewable by everyone" ON tournaments FOR SELECT USING (true);
CREATE POLICY "Authenticated users can create tournaments" ON tournaments FOR INSERT WITH CHECK (auth.role() = 'authenticated');
CREATE POLICY "Creators can update own tournaments" ON tournaments FOR UPDATE USING (auth.uid() = created_by);

-- Participants: viewable by all, insert own only
CREATE POLICY "Participants viewable by everyone" ON tournament_participants FOR SELECT USING (true);
CREATE POLICY "Users can join tournaments" ON tournament_participants FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Matches: viewable by all
CREATE POLICY "Matches viewable by everyone" ON matches FOR SELECT USING (true);

-- Transactions: only own transactions
CREATE POLICY "Users see own transactions" ON transactions FOR SELECT USING (auth.uid() = user_id);

-- Leaderboard: everyone can read
CREATE POLICY "Leaderboard viewable by everyone" ON leaderboard_points FOR SELECT USING (true);

-- =====================
-- FUNCTIONS
-- =====================

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO profiles (id, username, full_name)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'user_' || LEFT(NEW.id::TEXT, 8)),
    COALESCE(NEW.raw_user_meta_data->>'full_name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- =====================
-- SAMPLE DATA (optional - for testing)
-- =====================

-- Uncomment to add sample tournaments
/*
INSERT INTO tournaments (title, game, prize_pool, entry_fee, max_participants, status) VALUES
('E football', 'eFootball', 36000, 10000, 4, 'open'),
('Asphalt Kings TZ', 'Asphalt 9', 2000000, 150000, 8, 'live'),
('Free Fire Dar Open', 'Free Fire', 2500000, 200000, 16, 'open'),
('MK Knockout Night', 'Mortal Kombat', 500000, 50000, 8, 'completed');
*/
